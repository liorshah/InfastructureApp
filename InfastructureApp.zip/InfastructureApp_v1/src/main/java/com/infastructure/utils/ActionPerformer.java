package com.infastructure.utils;

import java.util.List;
import java.util.Map;

import com.infastructure.hibernate.actions.interfaces.IAction;

public class ActionPerformer{
	
	public <T extends Comparable<T>> void doAction(List<T> list, IAction action) {
		action.execute(list);
	}
	
}
