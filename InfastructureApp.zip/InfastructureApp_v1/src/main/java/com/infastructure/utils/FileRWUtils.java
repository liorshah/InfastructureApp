package com.infastructure.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.Scanner;

public class FileRWUtils {
	
	public void readFileToList(List<String> list,String filePath){
		
		try (Scanner s = new Scanner(new FileReader(filePath))) {
		    while (s.hasNext()) {
		    	list.add(s.nextLine());
		    }
		   
		} catch (FileNotFoundException e) {
			System.out.println("File not exist");
			e.printStackTrace();
		}
	}

	public void writeFile(List<String> lineList, String fileToWrite) throws IOException {
		
		try(FileWriter writer = new FileWriter(fileToWrite)){
			for(String str: lineList) {
				  writer.write(str + System.lineSeparator());
			}
		} catch (IOException e) {
			System.out.println("Error while writing to file");
			e.printStackTrace();
			throw e;
		} 
		
	}
}
