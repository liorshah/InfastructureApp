package com.infastructure.app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.infastructure.hibernate.actions.impl.BubbleSort;
import com.infastructure.hibernate.actions.impl.Reverse;
import com.infastructure.hibernate.actions.impl.Shuffle;
import com.infastructure.hibernate.actions.interfaces.IAction;
import com.infastructure.hibernate.dao.ActionDao;
import com.infastructure.hibernate.model.Action;
import com.infastructure.hibernate.service.ActionService;
import com.infastructure.utils.ActionPerformer;
import com.infastructure.utils.FileRWUtils;

public class App {

	private ActionService actionService = new ActionService();
	private ActionDao actionDao = new ActionDao();

	private Map<String, IAction> actions;
	private FileRWUtils fileReader;
	private ActionPerformer actionPerformer;

	public App() {
		init();
	}

	private void init() {
		// Set the actions
		this.actions = new HashMap<>();
		actions.put("sort", new BubbleSort());
		actions.put("shuffle", new Shuffle());
		actions.put("reverse", new Reverse());

		// Set fileReader
		fileReader = new FileRWUtils();

		// Set actionPerformer
		actionPerformer = new ActionPerformer();

		// Set dao
		actionService.setActionDao(actionDao);
	}

	// Add new user actions
	public void addActions(String aName, IAction actions) {
		this.actions.put(aName.toLowerCase(), actions);
	}

	// start the process
	public void start(String fileToRead, String fileToWrite, String action) {
		List<String> lineList = new ArrayList<>();

		// Check if action exist
		if (actions.containsKey(action.toLowerCase())) {
			// Read file and set line to list
			fileReader.readFileToList(lineList, fileToRead);
			if (lineList.size() > 0) {
				actionPerformer.doAction(lineList, actions.get(action));
				// Write to output file
				try {
					fileReader.writeFile(lineList, fileToWrite);
					System.out.println("File manuplated complite");

					// insert to db
					Action a = new Action();
					a.setFile_name(fileToRead);
					a.setManipulated_file_name(fileToWrite);
					a.setCreation_date(Calendar.getInstance().getTime());
					actionService.addAction(a);
				} catch (IOException e) {
					System.out.println("Error in file manuplated");
					e.printStackTrace();
				}
			}
		} else {
			System.out.println("Action not exist");
		}
	}

	public static void main(String[] args) {
		App app = new App();
		app.start("src/main/resources/readFile.txt", "src/main/resources/fileToWrite.txt", "sort");
	}
}
