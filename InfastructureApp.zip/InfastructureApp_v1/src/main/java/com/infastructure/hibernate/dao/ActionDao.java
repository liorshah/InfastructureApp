package com.infastructure.hibernate.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

 
import com.infastructure.hibernate.model.Action;
import com.infastructure.hibernate.util.HibernateUtil;

public class ActionDao {
	
	 //Create of CRUD
    public void addAction(Action action) {
           Transaction trns = null;
           Session session = HibernateUtil.getSessionFactory().openSession();
           try {
               trns = session.beginTransaction();
               session.save(action);
               session.getTransaction().commit();
           } catch (RuntimeException e) {
               if (trns != null) {
                   trns.rollback();
               }
               e.printStackTrace();
           } finally {
               session.flush();
               session.close();
               
           }
       }
}
