package com.infastructure.hibernate.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "action")
public class Action {
	
	long id;
	String file_name;
	String manipulated_file_name;
	Date  creation_date;

	public Action() {

	}

	public Action(long id, String file_name, String manipulated_file_name, Date creation_date) {
		this.file_name = file_name;
		this.manipulated_file_name = manipulated_file_name;
		this.creation_date = creation_date;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "action_id")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}



	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getManipulated_file_name() {
		return manipulated_file_name;
	}

	public void setManipulated_file_name(String manipulated_file_name) {
		this.manipulated_file_name = manipulated_file_name;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

}
