package com.infastructure.hibernate.service;

import com.infastructure.hibernate.dao.ActionDao;
import com.infastructure.hibernate.model.Action;

public class ActionService {

	private ActionDao actionDao;

	public void addAction(Action action) {
		actionDao.addAction(action);
	}

	public ActionDao getActionDao() {
		return actionDao;
	}

	public void setActionDao(ActionDao actionDao) {
		this.actionDao = actionDao;
	}
}
