package com.infastructure.hibernate.actions.impl;

import java.util.List;

import com.infastructure.hibernate.actions.interfaces.IAction;

public class BubbleSort implements IAction {

	public <T extends Comparable<T>> void execute(List<T> l) {
		T temp;
		boolean swapped = false;
		
		for(int i = 0; i < l.size() - 1; i++) {
			for(int j = 0; j < l.size() - i - 1 ; j++) {
				if(l.get(j).compareTo(l.get(j + 1)) >= 0) {
					temp = l.get(j);
					l.set(j, l.get(j+1));
					l.set(j + 1, temp);
					swapped = true;
				}
			}
			if (swapped == false)
	                break;
		}
	}

}
