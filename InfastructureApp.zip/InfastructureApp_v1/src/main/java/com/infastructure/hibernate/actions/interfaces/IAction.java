package com.infastructure.hibernate.actions.interfaces;

import java.util.List;

public interface IAction {
	<T extends Comparable<T>> void execute(List<T> l);
}
