package com.infastructure.hibernate.actions.impl;

import java.util.List;

import com.infastructure.hibernate.actions.interfaces.IAction;

public class Reverse implements IAction {

	public <T extends Comparable<T>> void execute(List<T> l) {
		
		T temp;
		int size = l.size();
		for(int i = 0; i <= (size / 2) - 1; i++) {
			temp = l.get(i);
			l.set(i, l.get(size - 1 - i));
			l.set(size - 1 - i, temp);
		}
	}
	
	
}
